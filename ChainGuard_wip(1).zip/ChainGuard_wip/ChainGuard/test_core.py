"""
ChainGuard Core Tests

Tests for core functionality including address validation, scoring, and signals.
"""

import pytest
import asyncio
from datetime import datetime, timedelta

from core.models import AddressAnalysisRequest, AddressType, RiskLevel
from risk_engine.scoring import ReputationScorer
from risk_engine.signals import SignalExtractor
from blockchain.demo_provider import DemoProvider
from blockchain.provider import Transaction


class TestAddressValidation:
    """Test address validation."""
    
    def test_valid_address(self):
        """Test valid EVM address."""
        request = AddressAnalysisRequest(address="0xabcd000000000000000000000000000000000001")
        assert request.address == "0xabcd000000000000000000000000000000000001"
    
    def test_address_case_insensitive(self):
        """Test address conversion to lowercase."""
        request = AddressAnalysisRequest(address="0xABCD000000000000000000000000000000000001")
        assert request.address == "0xabcd000000000000000000000000000000000001"
    
    def test_invalid_address_format(self):
        """Test invalid address format."""
        with pytest.raises(ValueError):
            AddressAnalysisRequest(address="not_an_address")
    
    def test_invalid_address_length(self):
        """Test address with wrong length."""
        with pytest.raises(ValueError):
            AddressAnalysisRequest(address="0x123")
    
    def test_invalid_hex_characters(self):
        """Test address with invalid hex characters."""
        with pytest.raises(ValueError):
            AddressAnalysisRequest(address="0xZZZZ000000000000000000000000000000000001")


class TestSignalExtraction:
    """Test signal extraction logic."""
    
    def test_no_transactions(self):
        """Test handling of address with no transactions."""
        extractor = SignalExtractor()
        signals, metrics = extractor.extract_signals(
            address="0x1234567890123456789012345678901234567890",
            transactions=[],
            is_contract=False,
        )
        
        assert len(signals) > 0
        assert metrics["transaction_count"] == 0
    
    def test_long_history_positive_signal(self):
        """Test that old addresses get positive signals."""
        extractor = SignalExtractor()
        now = datetime.utcnow()
        two_years_ago = now - timedelta(days=730)
        
        signals, metrics = extractor.extract_signals(
            address="0x1234567890123456789012345678901234567890",
            transactions=[
                Transaction(
                    hash="0x" + "a" * 64,
                    from_address="0x1234567890123456789012345678901234567890",
                    to_address="0x9999999999999999999999999999999999999999",
                    value=1.0,
                    gas_price=50.0,
                    gas_used=21000,
                    timestamp=two_years_ago,
                    block_number=1000000,
                )
            ],
            is_contract=False,
            first_tx_timestamp=two_years_ago,
        )
        
        # Should have positive signals for long history
        positive_signals = [s for s in signals if s.weight > 0]
        assert len(positive_signals) > 0
    
    def test_flagged_address_interaction(self):
        """Test detection of flagged address interactions."""
        flagged = ["0xbadaddress0000000000000000000000000000ba"]
        extractor = SignalExtractor(flagged_addresses=flagged)
        
        signals, _ = extractor.extract_signals(
            address="0x1234567890123456789012345678901234567890",
            transactions=[
                Transaction(
                    hash="0x" + "a" * 64,
                    from_address="0x1234567890123456789012345678901234567890",
                    to_address="0xbadaddress0000000000000000000000000000ba",
                    value=1.0,
                    gas_price=50.0,
                    gas_used=21000,
                    timestamp=datetime.utcnow(),
                    block_number=18000000,
                )
            ],
            is_contract=False,
        )
        
        # Should detect flagged interaction
        negative_signals = [s for s in signals if s.weight < 0]
        assert len(negative_signals) > 0


class TestScoring:
    """Test reputation scoring."""
    
    def test_base_score_with_no_signals(self):
        """Test scoring with empty signal list."""
        scorer = ReputationScorer()
        score, reasoning = scorer.calculate_score([])
        
        assert score == 50  # BASE_SCORE
        assert "No signals" in reasoning
    
    def test_positive_signals_increase_score(self):
        """Test that positive signals increase score."""
        from core.models import Signal, SignalType
        
        scorer = ReputationScorer()
        
        signals = [
            Signal(
                signal_type=SignalType.POSITIVE,
                name="Test Positive",
                description="Test",
                weight=10.0,
                source="test",
            )
        ]
        
        score, _ = scorer.calculate_score(signals)
        assert score > 50
    
    def test_negative_signals_decrease_score(self):
        """Test that negative signals decrease score."""
        from core.models import Signal, SignalType
        
        scorer = ReputationScorer()
        
        signals = [
            Signal(
                signal_type=SignalType.NEGATIVE,
                name="Test Negative",
                description="Test",
                weight=-10.0,
                source="test",
            )
        ]
        
        score, _ = scorer.calculate_score(signals)
        assert score < 50
    
    def test_score_clamping(self):
        """Test that scores are clamped to 0-100."""
        from core.models import Signal, SignalType
        
        scorer = ReputationScorer()
        
        # Extremely positive signals
        signals = [
            Signal(
                signal_type=SignalType.POSITIVE,
                name="Test",
                description="Test",
                weight=100.0,
                source="test",
            )
        ] * 10
        
        score, _ = scorer.calculate_score(signals)
        assert 0 <= score <= 100
    
    def test_risk_level_mapping(self):
        """Test score to risk level mapping."""
        scorer = ReputationScorer()
        
        assert scorer._score_to_risk_level(10) == RiskLevel.CRITICAL
        assert scorer._score_to_risk_level(30) == RiskLevel.HIGH
        assert scorer._score_to_risk_level(50) == RiskLevel.MODERATE
        assert scorer._score_to_risk_level(70) == RiskLevel.LOW
        assert scorer._score_to_risk_level(90) == RiskLevel.VERY_LOW


class TestDemoProvider:
    """Test demo provider functionality."""
    
    @pytest.mark.asyncio
    async def test_demo_address_exists(self):
        """Test that demo provider has sample addresses."""
        provider = DemoProvider()
        
        # Check a demo address
        addr = "0xabcd000000000000000000000000000000000001"
        is_contract = await provider.is_contract(addr)
        assert is_contract == False
        
        transactions = await provider.get_transactions(addr)
        assert len(transactions) > 0
    
    @pytest.mark.asyncio
    async def test_demo_contract_address(self):
        """Test demo contract address."""
        provider = DemoProvider()
        
        addr = "0xdead000000000000000000000000000000000002"
        is_contract = await provider.is_contract(addr)
        assert is_contract == True
        
        contract_info = await provider.get_contract_info(addr)
        assert contract_info is not None
    
    @pytest.mark.asyncio
    async def test_flagged_addresses(self):
        """Test flagged addresses list."""
        provider = DemoProvider()
        
        flagged = await provider.get_flagged_addresses()
        assert isinstance(flagged, list)


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
