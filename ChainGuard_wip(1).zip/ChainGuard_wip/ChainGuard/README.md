# ChainGuard: Web3 Wallet & Contract Reputation Intelligence

![ChainGuard Logo](frontend/assets/logo.svg)

## Overview

ChainGuard is an **explainable reputation intelligence system** for blockchain wallets and smart contracts. It analyzes on-chain activity to flag malicious transactions, exploit exposure, and provide transparent risk assessments backed by blockchain evidence.

### Problem Statement (Hackathon)

Users routinely interact with unknown wallets and smart contracts without knowing whether they can be trusted. ChainGuard solves this by:

1. **Analyzing wallet/contract interactions** across chains since inception
2. **Flagging malicious transactions** and associated risk signals
3. **Providing explainable evidence** rather than simple "good/bad" classifications
4. **Detecting compromise risks** including interactions with flagged contracts and unusual patterns

## Key Features

✅ **0-100 Reputation Score** - Transparent scoring with risk classification
✅ **Explainable Evidence** - Every signal backed by blockchain data
✅ **Real Blockchain Data** - Uses Etherscan API for live chain analysis
✅ **Demo Mode** - Works offline with realistic sample data
✅ **Address Detection** - Distinguishes wallets (EOA) from smart contracts
✅ **Interaction Graph** - Visual network of address relationships (planned)
✅ **Search History** - Track previously analyzed addresses
✅ **Professional UI** - Dark-themed responsive dashboard

## Tech Stack

**Backend:**
- FastAPI (async Python web framework)
- Web3.py (Ethereum integration)
- Pydantic (data validation)
- Etherscan API (blockchain data)

**Frontend:**
- Vanilla HTML/CSS/JavaScript
- No build tools required
- Responsive dark professional theme

**Database:**
- Async JSON storage for results and history
- Easy to migrate to PostgreSQL later

## Quick Start

### Prerequisites

- Python 3.8+
- pip
- curl or similar for testing API

### Installation

```bash
# Clone or download ChainGuard
cd ChainGuard

# Create virtual environment (recommended)
python -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate

# Install dependencies
pip install -r requirements.txt

# Copy environment template
cp .env.example .env
```

### Configuration

Edit `.env` with your settings:

```bash
# Demo mode (doesn't require API keys)
USE_DEMO_MODE=True
DEMO_MODE_DEFAULT=True

# Optional: Real blockchain API keys
ETH_MAINNET_ETHERSCAN=your_etherscan_api_key
ETH_SEPOLIA_ETHERSCAN=your_sepolia_api_key
```

Get free API keys:
- **Etherscan**: https://etherscan.io/apis
- **Groq LLM** (optional): https://console.groq.com

### Running Locally

```bash
# Start the application
python main.py

# Application will be available at http://localhost:5000
```

Then open your browser and navigate to `http://localhost:5000`

## Usage

### Analyze an Address

1. **Enter an address** in the search box (0x-format EVM address)
2. **Click Analyze**
3. **View results**:
   - Reputation score (0-100)
   - Risk level (Critical/High/Moderate/Low/Very Low)
   - Individual signals with evidence
   - Activity metrics
   - Recommendations

### Demo Addresses

Try these demo addresses in demo mode:

| Address | Scenario | Score |
|---------|----------|-------|
| `0xabcd000000000000000000000000000000000001` | Legitimate holder | 75 |
| `0xdead000000000000000000000000000000000002` | Suspicious contract | 35 |
| `0xdefi0000000000000000000000000000000000003` | Active DeFi user | 82 |

### Search History

ChainGuard remembers your recent analyses in the browser's local storage and server cache. Click "History" to see previous results.

## API Endpoints

### Health Check
```bash
GET /health
```

### Analyze Address
```bash
POST /api/analyze
Content-Type: application/json

{
  "address": "0x1234567890123456789012345678901234567890",
  "chain": "ethereum_mainnet",
  "include_transactions": true,
  "include_graph": true
}
```

Response: Complete analysis with reputation score, signals, and evidence

### Get Cached Analysis
```bash
GET /api/address/{address}?chain=ethereum_mainnet
```

### Search History
```bash
GET /api/history
```

## How It Works

### Architecture

```
User Input
    ↓
Address Validation
    ↓
Blockchain Data Fetch (Etherscan API / Demo Provider)
    ↓
Data Normalization
    ↓
Signal Extraction (40+ signals)
    ↓
Risk Engine Scoring (Deterministic, Explainable)
    ↓
Evidence Generation
    ↓
Result Display & Caching
```

### Reputation Score Calculation

Score ranges from **0 to 100**:

- **Base Score**: 50 points
- **Positive Signals**: +1 to +5 points each
  - Long activity history
  - Established contracts
  - Consistent behavior
- **Negative Signals**: -5 to -20 points each
  - Flagged address interactions
  - Unusual activity patterns
  - Unverified contracts
  - Recent suspicious activity

**Score is fully deterministic** - same address always gets same score (until blockchain changes)

### Risk Levels

| Score | Level | Recommendation |
|-------|-------|-----------------|
| 0-20 | 🚫 CRITICAL | Do not interact |
| 21-40 | ⚠️ HIGH | Extreme caution required |
| 41-60 | ⚠️ MODERATE | Proceed cautiously |
| 61-80 | ✓ LOW | Generally safe |
| 81-100 | ✓✓ VERY LOW | Established address |

### Signals Analyzed

**Positive Signals:**
- Long transaction history (1+ year)
- High transaction volume (100+ txs)
- Interactions with established protocols
- Consistent behavior patterns

**Negative Signals:**
- Interaction with known flagged addresses
- Unusual transaction frequency spikes
- Failed transaction bursts
- Newly deployed contracts
- Unverified smart contracts
- Suspicious permission patterns

## Demo Mode

ChainGuard works perfectly in **demo mode** without API keys:

✅ No internet required
✅ Realistic sample addresses
✅ Full UI demonstration
✅ Clearly labeled "DEMO DATA"

Demo mode is enabled by default in `.env`. Live blockchain mode requires Etherscan API key.

## Testing

Run the test suite:

```bash
# Run all tests
pytest tests/ -v

# Run specific test file
pytest tests/test_core.py -v

# Run with coverage
pytest tests/ --cov=core --cov=risk_engine --cov=blockchain
```

Test coverage includes:
- Address validation
- Signal extraction
- Risk scoring
- Demo provider
- API endpoints

## Project Structure

```
ChainGuard/
├── core/                          # Core models and configuration
│   ├── config.py                 # Settings from environment
│   ├── models.py                 # Pydantic data models
│   └── constants.py              # Constants
│
├── blockchain/                    # Blockchain data fetching
│   ├── provider.py               # Abstract provider
│   ├── eth_provider.py           # Ethereum implementation
│   └── demo_provider.py          # Demo data provider
│
├── risk_engine/                  # Reputation scoring engine
│   ├── signals.py                # Signal extraction
│   ├── scoring.py                # Score calculation
│   └── rules.py                  # Risk rules
│
├── routers/                      # FastAPI routes
│   ├── health.py                 # Health checks
│   ├── analyze.py                # Main analysis endpoint
│   ├── address.py                # Address details
│   └── history.py                # Search history
│
├── frontend/                     # Web UI
│   ├── index.html                # Main page
│   ├── styles.css                # Styling
│   └── js/
│       ├── api.js                # API client
│       └── app.js                # UI logic
│
├── tests/                        # Test suite
│   └── test_core.py              # Core tests
│
├── docs/                         # Documentation
│   ├── ARCHITECTURE.md           # System design
│   ├── RISK_ENGINE.md            # Scoring details
│   ├── API_DOCUMENTATION.md      # API reference
│   └── ...
│
├── main.py                       # FastAPI app entry point
├── requirements.txt              # Python dependencies
├── .env.example                  # Environment template
└── README.md                     # This file
```

## Configuration

### Environment Variables

```bash
# Application
APP_NAME=ChainGuard
APP_VERSION=1.0.0
DEBUG=False

# Server
HOST=0.0.0.0
PORT=5000

# Blockchain APIs
ETH_MAINNET_ETHERSCAN=your_key_here
ETH_SEPOLIA_ETHERSCAN=your_key_here

# Demo mode
USE_DEMO_MODE=True
DEMO_MODE_DEFAULT=True

# Optional: AI explanations
GROQ_API_KEY=your_key_here
ENABLE_AI_EXPLAINER=False
```

## Limitations & Disclaimers

⚠️ **Important**: ChainGuard provides a heuristic risk assessment, NOT a guarantee of safety.

- **False Positives**: Legitimate addresses may be flagged
- **False Negatives**: Malicious addresses may receive high scores
- **Data Incompleteness**: Only analyzes public blockchain data
- **Limited History**: Can only see transactions on supported networks
- **Not a Security Audit**: Cannot detect contract vulnerabilities
- **No Private Keys**: We never request or store private keys or seed phrases

For critical transactions, always:
1. Review evidence directly on blockchain explorers
2. Use professional security audits for large amounts
3. Verify contract source code independently

## Hackathon Submission

This project was built for a Web3 hackathon. See:
- `HACKATHON_PITCH.md` - 30-second to 5-minute pitches
- `PROJECT_AUDIT.md` - Technical evaluation
- `DEVELOPMENT_GUIDE.md` - Codebase walkthrough

## Future Improvements

- ⬜ Multi-chain support (Polygon, Arbitrum, Optimism)
- ⬜ Advanced contract analysis (proxy detection, admin patterns)
- ⬜ ML-based anomaly detection
- ⬜ Community reporting integration
- ⬜ Browser extension
- ⬜ API monetization for integrations

## Security

ChainGuard is **read-only** - it never:
- Signs transactions
- Requests private keys
- Executes contract calls
- Modifies blockchain state

All data validation occurs server-side. Frontend does basic checks only.

## License

[Specify license - MIT, Apache, etc.]

## Support

- **Issues**: Report via GitHub issues
- **Docs**: See `/docs` directory
- **Questions**: See FAQ in documentation

---

**ChainGuard: Know Before You Interact** 🔗
