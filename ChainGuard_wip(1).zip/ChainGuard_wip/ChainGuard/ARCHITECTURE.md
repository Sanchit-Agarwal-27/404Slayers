# ChainGuard System Architecture

## High-Level Overview

```
┌─────────────────────────────────────────────────────────────────┐
│                        Frontend (Browser)                        │
│  HTML/CSS/JavaScript - Responsive Web Dashboard                 │
└──────────────────────┬──────────────────────────────────────────┘
                       │ HTTP/JSON
                       ↓
┌─────────────────────────────────────────────────────────────────┐
│                    FastAPI Backend Server                        │
│                   (Python Async Application)                     │
├─────────────────────────────────────────────────────────────────┤
│  API Routers:                                                    │
│  ├─ POST /api/analyze     - Main analysis endpoint               │
│  ├─ GET /api/address/{addr} - Cached results                    │
│  ├─ GET /api/history      - Search history                      │
│  └─ GET /health           - Health check                        │
└──────────┬────────────────┬────────────────┬─────────────────────┘
           │                │                │
           ↓                ↓                ↓
    ┌────────────┐  ┌───────────────┐  ┌──────────────┐
    │Blockchain  │  │  Risk Engine  │  │   Database  │
    │Provider    │  │   Scoring     │  │   (JSON)    │
    └────────────┘  └───────────────┘  └──────────────┘
           │
    ┌──────┴──────┐
    ↓             ↓
┌──────────┐  ┌──────────────┐
│Etherscan │  │Demo Provider │
│API       │  │(Sample Data) │
└──────────┘  └──────────────┘
```

## Component Architecture

### 1. Frontend Layer

**Technology**: Vanilla HTML/CSS/JavaScript (No frameworks)

**Responsibilities:**
- User input/address entry
- Result visualization
- History management
- Error handling

**Files:**
- `frontend/index.html` - Main page structure
- `frontend/styles.css` - Responsive styling
- `frontend/js/api.js` - Backend API communication
- `frontend/js/app.js` - Application logic

**Key Components:**
- Landing page with address search
- Analysis result dashboard
- Risk score visualization
- Signal display cards
- Search history page

### 2. API Layer (FastAPI)

**Entry Point**: `main.py`

**Responsibilities:**
- Request routing
- Request/response validation
- CORS handling
- Static file serving

**Routers**:
- `routers/health.py` - Health checks, status
- `routers/analyze.py` - Address analysis (main endpoint)
- `routers/address.py` - Address detail retrieval
- `routers/history.py` - Search history

**Features:**
- Async/await for concurrency
- Pydantic validation on all requests
- Graceful error handling
- CORS support for frontend

### 3. Data Models Layer

**File**: `core/models.py`

**Models:**
- `AddressAnalysisRequest` - User analysis request
- `AddressAnalysisResponse` - Complete analysis result
- `ReputationScore` - Score with signals and reasoning
- `Signal` - Individual risk/positive signal
- `ActivityMetrics` - Transaction metrics
- `AddressInfo` - Address metadata
- `ContractInfo` - Smart contract details
- `SearchHistoryEntry` - Historical record

### 4. Blockchain Integration Layer

**Abstract Interface**: `blockchain/provider.py`

**Implementations:**
- `EthereumProvider` (eth_provider.py) - Live blockchain data via Etherscan
- `DemoProvider` (demo_provider.py) - Deterministic sample data

**Responsibilities:**
- Fetch transaction history
- Detect address type (EOA vs contract)
- Get contract source code
- Fetch token transfers
- Get balance information
- Check flagged addresses

**Data Flow:**
```
Address Input
    ↓
Provider.get_transactions() → List[Transaction]
    ↓
Provider.is_contract() → bool
    ↓
Provider.get_contract_info() → Optional[Contract]
    ↓
Provider.get_balance() → float
    ↓
Provider.get_token_transfers() → List[TokenTransfer]
```

### 5. Risk Engine (Core Logic)

**Entry Point**: `risk_engine/scoring.py`

**Components:**

#### a. Signal Extraction (`signals.py`)
Analyzes blockchain data and extracts risk/positive signals:
- Activity-based signals (transaction volume, frequency)
- Behavior-based signals (unusual patterns)
- Counterparty-based signals (flagged interactions)
- Contract-specific signals (verification status, age)
- Token transfer signals
- Time-based signals (account age)

#### b. Scoring (`scoring.py`)
Calculates final reputation score:
- Base score: 50 points
- Apply positive signals (+1 to +5)
- Apply negative signals (-5 to -20)
- Clamp to 0-100 range
- Classify risk level

#### c. Rules (`rules.py`)
Define scoring rules and thresholds (future expansion)

**Scoring Algorithm:**
```python
score = BASE_SCORE (50)
for each signal in extracted_signals:
    score += signal.weight
score = clamp(score, 0, 100)
risk_level = score_to_risk_level(score)
```

### 6. Database Layer

**File**: `mock_db.py`

**Storage Method**: Async JSON files

**Tables:**
- `analyses.json` - Cached analysis results
- `search_history.json` - User analysis history

**Features:**
- Asyncio locks for thread-safety
- JSON-based persistence
- Easy migration path to PostgreSQL

**API:**
```python
save_analysis(address, chain, data)
get_analysis(address, chain) → Optional[Dict]
add_to_search_history(address, chain, score, risk_level, is_demo)
get_search_history() → List[Dict]
```

### 7. Configuration Layer

**File**: `core/config.py`

**Features:**
- Pydantic BaseSettings for environment variables
- Network configurations
- Risk score thresholds
- Signal weights (configurable)
- Demo address data
- API key management

**Security:**
- Never hardcodes secrets
- Uses environment variables
- Validates all inputs

## Data Flow Diagrams

### Analysis Request Flow

```
1. User enters address in frontend
   ↓
2. Frontend validates address locally
   ↓
3. POST /api/analyze to backend
   ↓
4. Backend validates with Pydantic model
   ↓
5. Get blockchain provider (Etherscan or Demo)
   ↓
6. Fetch transaction history
7. Fetch contract info (if contract)
8. Fetch balance
9. Fetch token transfers
   ↓
10. Extract signals from data
    ├─ Analyze activity patterns
    ├─ Check for flagged addresses
    ├─ Evaluate contract properties
    └─ Time-based analysis
   ↓
11. Calculate reputation score
    ├─ Apply signal weights
    ├─ Generate reasoning
    └─ Classify risk level
   ↓
12. Save to cache and history
   ↓
13. Return response to frontend
   ↓
14. Frontend displays results
```

### Signal Extraction Flow

```
Blockchain Data
    ├─ Transactions: List[Transaction]
    ├─ Is Contract: bool
    ├─ Contract Info: Optional[Contract]
    ├─ Balance: float
    ├─ Token Transfers: List[Dict]
    └─ First TX Time: Optional[DateTime]
    ↓
Signal Extractor
    ├─ Activity Analysis
    │  ├─ Transaction count
    │  ├─ Failed transactions
    │  └─ Frequency patterns
    │
    ├─ Behavior Analysis
    │  ├─ Recent spikes
    │  └─ Unusual patterns
    │
    ├─ Counterparty Analysis
    │  └─ Flagged address interactions
    │
    ├─ Contract Analysis
    │  ├─ Verification status
    │  ├─ Proxy detection
    │  └─ Deployment age
    │
    └─ Time Analysis
       └─ Account age
    ↓
List[Signal]
    ├─ Name
    ├─ Description
    ├─ Weight
    ├─ Evidence
    └─ Confidence
```

## Request/Response Cycle

### Analysis Request

```json
POST /api/analyze
{
  "address": "0x1234567890123456789012345678901234567890",
  "chain": "ethereum_mainnet",
  "include_transactions": true,
  "include_graph": true
}
```

### Analysis Response

```json
{
  "address_info": {
    "address": "0x1234...",
    "address_type": "eoa",
    "chain": "Ethereum Mainnet",
    "chain_id": 1,
    "activity_metrics": {
      "transaction_count": 142,
      "unique_counterparties": 37,
      ...
    }
  },
  "reputation_score": {
    "score": 75,
    "risk_level": "low",
    "signals": [
      {
        "signal_type": "positive",
        "name": "Long Activity History",
        "weight": 5.0,
        ...
      }
    ],
    "reasoning": "..."
  },
  "is_demo_data": false,
  "timestamp": "2024-01-01T12:00:00"
}
```

## Error Handling

### Levels

1. **Validation Layer** - Pydantic validates all inputs
2. **API Layer** - FastAPI error handlers
3. **Provider Layer** - Graceful fallbacks
4. **Frontend Layer** - User-friendly messages

### Common Errors

```python
# Invalid address
HTTPException(400, "Invalid EVM address format")

# No blockchain data
HTTPException(404, "Address not analyzed yet")

# API failure
# Automatically falls back to demo mode
logger.error("API failed, using demo data")

# Database error
HTTPException(500, "Database error")
```

## Caching Strategy

### What's Cached

- Analysis results (key: `chain:address`)
- Search history (per-user, in JSON file)
- Flagged addresses list (in memory)

### Cache Invalidation

- Analysis: TTL-based (60 minutes default)
- History: Never automatically deleted (user can clear)
- Flagged: Updated on provider init

## Scalability Considerations

### Current Design (Hackathon)

- Single instance deployment
- JSON-based storage
- In-memory flagged addresses
- Synchronous blockchain API calls

### Production Improvements

1. **Database**: PostgreSQL with proper indexes
2. **Caching**: Redis for hot data
3. **Queue**: Celery for background analysis
4. **Monitoring**: Prometheus metrics
5. **CDN**: Frontend asset delivery
6. **Load Balancing**: Multiple FastAPI instances
7. **Rate Limiting**: Per-user/IP limits

## Security Architecture

### Input Validation
- All user inputs validated with Pydantic
- Address format checked on frontend + backend
- Maximum payload size limits

### API Security
- CORS configured
- No sensitive data in logs
- Environment variables for secrets
- No API keys exposed to frontend

### Data Protection
- Read-only operations (no blockchain write)
- Cache is local (not shared)
- No user authentication required (public data)
- Search history stored locally (no tracking)

### Error Messages
- Generic error responses to users
- Detailed logs for debugging
- No stack traces exposed

## Testing Architecture

**Test Levels:**
1. Unit tests - Core logic (signals, scoring)
2. Integration tests - Provider + scoring
3. API tests - Endpoint validation
4. End-to-end - Full flow testing

**Test Files:**
- `tests/test_core.py` - Core functionality
- `tests/test_blockchain.py` - Provider tests
- `tests/test_api.py` - API endpoint tests

**Coverage:**
- Target: 80%+ code coverage
- Focus on risk scoring logic
- Address validation
- Signal extraction

## Deployment

### Docker (Recommended)

```dockerfile
FROM python:3.11
WORKDIR /app
COPY requirements.txt .
RUN pip install -r requirements.txt
COPY . .
CMD ["python", "main.py"]
```

### Environment

```yaml
# docker-compose.yml
services:
  chainguard:
    build: .
    ports:
      - "5000:5000"
    environment:
      - ETH_MAINNET_ETHERSCAN=${ETHERSCAN_KEY}
      - USE_DEMO_MODE=True
    volumes:
      - ./data:/app/data
```

### Monitoring

- Health endpoint: `GET /health`
- Prometheus metrics (future)
- Error logging to stdout/file
- Performance monitoring

## Performance Characteristics

### Typical Analysis Time

- Demo data: < 100ms
- Etherscan API: 1-3 seconds
  - Network latency: ~500ms
  - Data fetching: 1-2s
  - Signal extraction: ~200ms
  - Scoring: < 10ms

### Memory Usage

- Base: ~100 MB
- Per-request: ~10-20 MB
- Cached analyses: Negligible

### Database Size

- Per analysis: ~50-100 KB JSON
- Demo addresses: ~20 KB
- Search history: ~1-2 MB (100 entries)

---

**Architecture v1.0 - Hackathon Implementation**
