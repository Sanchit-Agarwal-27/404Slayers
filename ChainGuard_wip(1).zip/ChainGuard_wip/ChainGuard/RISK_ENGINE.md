# ChainGuard Risk Engine: Detailed Scoring Documentation

## Overview

The Risk Engine is the core of ChainGuard. It transforms raw blockchain data into an explainable 0-100 reputation score through a multi-stage process:

```
Blockchain Data → Signal Extraction → Weighting → Score Calculation → Risk Classification
```

This document explains exactly how each signal affects the score and why.

## Scoring Formula

### Base Score
```
Initial Score = 50
```

Every address starts at 50 (neutral). This means:
- Addresses with no data aren't immediately flagged
- Positive signals can increase trust
- Negative signals decrease trust

### Signal Application
```
Final Score = Base Score + Σ(signal.weight × signal.confidence)
Final Score = clamp(Final Score, 0, 100)
```

### Risk Level Classification
```
0-20    → CRITICAL   (🚫 Do not interact)
21-40   → HIGH       (⚠️ Exercise extreme caution)
41-60   → MODERATE   (⚠️ Proceed carefully)
61-80   → LOW        (✓ Generally safe)
81-100  → VERY LOW   (✓✓ Established, trusted)
```

## Signal Catalog

### Positive Signals (Increase Score)

#### 1. Long Activity History
- **Weight**: +5 points
- **Condition**: Account active for 365+ days
- **Why**: Accounts that have been operational for years are less likely to be scams
- **Evidence**: First transaction timestamp, block number
- **Limitation**: Doesn't guarantee safety, just longevity

#### 2. Established History
- **Weight**: +3 points
- **Condition**: Account active for 180-365 days
- **Why**: 6+ months of activity shows some commitment
- **Evidence**: Time span of operations

#### 3. High Transaction Volume
- **Weight**: +3 points
- **Condition**: 1000+ transactions
- **Why**: Heavy usage indicates established user, less likely dormant
- **Evidence**: Transaction count analysis

#### 4. Moderate Transaction Volume
- **Weight**: +2 points
- **Condition**: 100-1000 transactions
- **Why**: Some activity history
- **Evidence**: Transaction count

#### 5. Verified Smart Contract
- **Weight**: +2 points
- **Condition**: Contract source code is verified on Etherscan
- **Why**: Verified contracts allow inspection, harder to hide malicious code
- **Evidence**: Etherscan verification status

#### 6. Active Token Holder
- **Weight**: +2 points
- **Condition**: 100+ token transfers
- **Why**: Engagement with multiple tokens shows active participation
- **Evidence**: Token transfer history

### Negative Signals (Decrease Score)

#### 1. Interaction with Flagged Addresses
- **Weight**: -20 points ⚠️ **CRITICAL**
- **Condition**: Interacted with known malicious/compromised address
- **Why**: Association with flagged addresses is the strongest indicator
- **Evidence**: Transaction hash, block number, flagged address list
- **Confidence**: 0.95 (very high)
- **Note**: This is the single strongest negative signal

#### 2. Unverified Smart Contract
- **Weight**: -10 points
- **Condition**: Contract bytecode doesn't have verified source
- **Why**: Cannot inspect code → potential hidden malicious behavior
- **Evidence**: Etherscan verification status
- **Mitigation**: Can be mitigated by long history + many interactions

#### 3. Unusual Transaction Frequency
- **Weight**: -12 points
- **Condition**: 20+ transactions in last 7 days with 30%+ failure rate
- **Why**: Sudden activity surge + failures suggests targeting/testing
- **Evidence**: Transaction timestamps, failure flags

#### 4. High Failed Transaction Rate
- **Weight**: -5 points
- **Condition**: > 50% of transactions failed
- **Why**: Indicates problems or attempted attacks
- **Evidence**: Transaction status (success/failure)

#### 5. Elevated Failed Transactions
- **Weight**: -2 points
- **Condition**: 20-50% failure rate
- **Why**: Abnormal but not critical
- **Evidence**: Transaction statuses

#### 6. Recently Deployed Contract
- **Weight**: -10 points
- **Condition**: Contract deployed < 30 days ago
- **Why**: New contracts are higher risk - no history to verify
- **Evidence**: Creation block timestamp

#### 7. Unverified Proxy Contract
- **Weight**: -8 points
- **Condition**: Proxy contract with unverified implementation
- **Why**: Cannot see implementation logic → potential rug pull
- **Evidence**: Proxy pattern detection + verification status

#### 8. New Address
- **Weight**: -5 points
- **Condition**: Account created < 30 days ago
- **Why**: Brand new accounts could be fresh scams/attacks
- **Evidence**: First transaction timestamp

## Examples: How Scores Are Calculated

### Example 1: Legitimate Old Account

**Data:**
- First seen: January 2020 (4+ years)
- Transactions: 500
- Contract interactions: 15 established protocols
- Failed transactions: 2%
- Status: No flagged interactions

**Signals:**
```
Base Score:              50
+ Long History:          +5
+ High TX Volume:        +3
+ Established Interaction: +2
= Final Score:           60

Risk Level: MODERATE
Reasoning: Established account with good history.
           No risk signals detected.
```

### Example 2: Suspicious New Contract

**Data:**
- Created: 5 days ago
- Transactions: 150 (100 failed)
- Owner: Unknown
- Verification: None
- Interactions: Flagged address x3

**Signals:**
```
Base Score:              50
+ No positive signals:    0
- Recently Deployed:     -10
- High Failure Rate:     -5
- Flagged Interaction:   -20
- Unverified:            -10
= Final Score:           5

Risk Level: CRITICAL
Reasoning: Brand new contract with suspicious properties,
           failed transactions, and flagged interactions.
           DO NOT INTERACT.
```

### Example 3: Active DeFi User

**Data:**
- First seen: September 2022 (1+ years)
- Transactions: 2000+
- Token interactions: 50+ different tokens
- Contract failures: <5%
- Recent activity: 25 transactions (all successful)
- Interactions: All with verified major protocols (Uniswap, Aave, etc.)

**Signals:**
```
Base Score:              50
+ Long History:          +5
+ Very High TX Volume:   +3
+ Active Token Holder:   +2
+ Verified Interactions: +2 (implied by protocol age)
= Final Score:           82

Risk Level: LOW
Reasoning: Active, established participant with clean
           transaction history and major protocol interactions.
```

## Confidence Scores

Each signal has an associated confidence (0.0-1.0):

```python
# High confidence (0.95)
"Interaction with flagged address" - Clear blockchain fact

# Medium confidence (0.75)
"Unusual frequency pattern" - Pattern-based, could have false positives

# Lower confidence (0.60)
"Suspicious contract" - Based on absence (no verification)
```

**Confidence is multiplied into weight:**
```
Final Impact = Weight × Confidence
```

## Limitations & False Positives

### What Can Cause False Positives

1. **Legitimate new contracts**
   - Some new projects are legitimate
   - Score improves as contract ages

2. **Batch operations with failures**
   - Some legitimate workflows have failures
   - Score reflects this but doesn't classify as scam

3. **Privacy wallets**
   - Complex transaction patterns
   - May show as "unusual" but legitimate

4. **Compromised flagged lists**
   - Flagged addresses might be outdated
   - Manual review always recommended

### What Can Cause False Negatives

1. **Hidden vulnerabilities**
   - Verified contract code can still be vulnerable
   - This is NOT a security audit

2. **Governance attacks**
   - Contracts can be compromised after deployment
   - Reputation is point-in-time

3. **New scam patterns**
   - Novel attack vectors not yet in flagged list
   - System learns over time

4. **Whale wallets**
   - Large legitimate wallets might have unusual patterns
   - Confidence scores help mitigate

## Customization

### Adjusting Weights

Edit `core/config.py`:

```python
SIGNAL_WEIGHTS = {
    "long_history": 5,           # Increase to be more forgiving of age
    "flagged_address_interaction": -20,  # Strongest negative signal
    # ... customize any weights ...
}
```

### Adding New Signals

1. **Define signal extraction** in `risk_engine/signals.py`
2. **Add weight** in `core/config.py`
3. **Create test** in `tests/test_core.py`
4. **Document** in this file

Example:
```python
# Add to signals.py
def _new_signal(self, transactions):
    if some_condition(transactions):
        signals.append(
            self._create_signal(
                SignalType.NEGATIVE,
                "Signal Name",
                "Description",
                -10,  # weight
                "source"
            )
        )
```

## Data Quality Impact on Scoring

### Assumption: Complete Data
We assume Etherscan API provides complete transaction history. In reality:
- Some transactions may be missing (old data, indexing delays)
- Large accounts may have historical cutoffs
- Token transfers may be incomplete

**Impact**: Scores may be slightly higher than true risk (missing negative data)

### Mitigation
- Demo mode provides realistic sample size
- Score is relative, not absolute
- Multiple analysis runs should converge
- Manual review always recommended

## Comparison with Other Systems

| Aspect | ChainGuard | Traditional Rating | ML-Based |
|--------|-----------|-------------------|----------|
| **Explainability** | Full (every signal shown) | Partial | Black box |
| **Data Sources** | Blockchain only | Multiple sources | Proprietary |
| **Speed** | 1-3 seconds | Minutes | Depends |
| **Accuracy** | Heuristic | Better but slower | Unknown |
| **Transparency** | 100% - see formula | No | No |
| **Bias** | Defined rules | Human bias | Training bias |

## Testing Signal Accuracy

### Backtesting

Could test against known scams:
```python
# Pseudocode
for scam_addr in known_scams:
    score = calculate_score(scam_addr)
    assert score < 40, f"Scam classified as safe: {scam_addr}"
```

### Validation

- Demo addresses designed to test scenarios
- Unit tests verify signal extraction
- Manual analysis of edge cases

## Future Enhancements

### Planned Improvements

1. **Machine Learning**
   - Train on labeled address datasets
   - Improve signal weighting

2. **Cross-Chain Analysis**
   - Analyze interactions across networks
   - Detect multi-chain patterns

3. **Time Series Analysis**
   - Track score evolution over time
   - Detect degradation

4. **Community Scoring**
   - User reports of addresses
   - Crowdsourced threat intel

5. **Smart Contract Analysis**
   - Formal verification results
   - Audit report integration

## Debugging Scores

### Check Signal Extraction

1. Look at returned signals in API response
2. Each signal shows:
   - Name (what was detected)
   - Description (why it matters)
   - Weight (impact on score)
   - Evidence (supporting data)

### Verify Calculation

```python
# Manual verification
base = 50
for signal in signals:
    impact = signal['weight'] * signal.get('confidence', 1.0)
    base += impact
    print(f"{signal['name']}: {impact:+.1f} → {base}")
final = clamp(base, 0, 100)
```

### Compare Addresses

Comparing two addresses of different scores can reveal:
- Which signals differ
- Why one is riskier than the other

---

**Risk Engine v1.0 - Hackathon Implementation**
**Last Updated: 2024**
