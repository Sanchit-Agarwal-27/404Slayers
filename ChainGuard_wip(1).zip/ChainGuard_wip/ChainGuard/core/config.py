"""
ChainGuard Configuration

Loads environment variables with validation via pydantic-settings.
Governs demo/live mode selection, supported networks, and risk thresholds.
"""

from pydantic_settings import BaseSettings
from functools import lru_cache


class Settings(BaseSettings):
    """Application settings loaded from environment variables (.env)."""

    # Application
    app_name: str = "ChainGuard"
    app_version: str = "1.0.0"
    debug: bool = False

    # Server
    host: str = "0.0.0.0"
    port: int = 5000

    # Blockchain Configuration
    # Ethereum Mainnet
    eth_mainnet_rpc: str = ""
    eth_mainnet_etherscan: str = ""

    # Sepolia Testnet
    eth_sepolia_rpc: str = ""
    eth_sepolia_etherscan: str = ""

    # Mode selection.
    # USE_DEMO_MODE is the single source of truth for demo vs. live.
    # ChainGuard NEVER silently falls back from live to demo: if this is
    # False and a chain's API key is missing, the analyze endpoint returns
    # a clear error rather than quietly substituting demo data.
    use_demo_mode: bool = True

    # HTTP client
    provider_timeout_seconds: int = 15
    max_counterparty_classification_calls: int = 12

    # Risk Engine
    risk_engine_version: str = "1.0"
    reputation_score_min: int = 0
    reputation_score_max: int = 100

    # LLM Configuration (Optional) — explanation assistant only.
    # The LLM is NEVER used to calculate the score or invent evidence.
    groq_api_key: str = ""
    enable_ai_explainer: bool = False

    # Storage
    db_path: str = "data"

    class Config:
        env_file = ".env"
        case_sensitive = False


@lru_cache()
def get_settings() -> Settings:
    """Get cached settings instance."""
    return Settings()


# Supported network configurations
NETWORKS = {
    "ethereum_mainnet": {
        "name": "Ethereum Mainnet",
        "chain_id": 1,
        "currency": "ETH",
        "explorer": "https://etherscan.io",
        "rpc_key": "eth_mainnet_rpc",
        "etherscan_key": "eth_mainnet_etherscan",
        "etherscan_url": "https://api.etherscan.io/api",
    },
    "sepolia": {
        "name": "Sepolia Testnet",
        "chain_id": 11155111,
        "currency": "ETH",
        "explorer": "https://sepolia.etherscan.io",
        "rpc_key": "eth_sepolia_rpc",
        "etherscan_key": "eth_sepolia_etherscan",
        "etherscan_url": "https://api-sepolia.etherscan.io/api",
    },
}

# Risk score -> risk level thresholds (inclusive upper bounds)
RISK_LEVELS = {
    "critical": (0, 20),
    "high": (21, 40),
    "moderate": (41, 60),
    "low": (61, 80),
    "very_low": (81, 100),
}
